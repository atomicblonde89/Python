def letra_o (n):
   ancho = n
   asterisco =""
   for i in range(ancho):
       if i == 0:
           asterisco += "*" * ancho + "\n"
       elif i == ancho - 1:
           asterisco += "*" * ancho + "\n"
       else: 
           asterisco += "*" + "" * (ancho-2) + "*" + "\n"
  
   return asterisco[:-1]

string_asteriscos = letra_o(int(input()))