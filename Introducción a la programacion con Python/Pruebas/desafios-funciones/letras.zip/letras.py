import string

def gen(num):
	
	return string.ascii_lowercase[:num]
	
letras_concatenadas = gen(int(input()))
