def letra_i (n):
   ancho = n
   asterisco = ''
   for i in range(ancho):
       if i == 0 or i == ancho-1:
			     asterisco += '*' * ancho + '\n'
       else:
			     asterisco += ' '* int((ancho-1)/2) + '*' + ' '* int((ancho-1)/2) + '\n'
	
   return asterisco

string_asteriscos = letra_i(int(input()))
