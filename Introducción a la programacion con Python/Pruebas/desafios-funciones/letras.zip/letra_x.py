def letra_x (n):
    asteriscos = ""
    resta = n-2

    for i in range(n):
         if i == 0 or i == n-1:
             asteriscos += "*" + ("" *(n-2)) + "*" + "\n"
         elif i == ((n-1)/2):
             asteriscos += i*"" "+"*"+" "*i+\n"
         elif i < ((n-1)/2):
             resta -= 2
             asteriscos += (""*i) + "*" + (""*(resta)) + "*" + (""*i) + "\n"
         elif i > ((n-1)/2):
             asteriscos += (""*(i-resta-1)) + "*"+ (""*resta) + "*" + (""*(i-resta-1)) + "\n"
    
    return asteriscos
string_asteriscos = letra_x(int(input()))